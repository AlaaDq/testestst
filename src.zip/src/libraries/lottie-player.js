export { Player } from "@lottiefiles/react-lottie-player";
