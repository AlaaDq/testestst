export { Player } from "./lottie-player";
