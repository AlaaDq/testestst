import "./App.css";
// import { HeaderContainer } from "./components";
// import { useBreakpoint } from "./hooks/useBreakpoint";
import { Home } from "./pages";
function App() {
  // const breakpoint =useBreakpoint();
  return (
    <>
      <Home />
      {/* <HeaderContainer /> */}
    </>
  );
}

export default App;
