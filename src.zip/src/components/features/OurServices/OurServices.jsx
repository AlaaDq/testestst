import React from "react";
import { Service } from ".";
import "./OurServices.css";

export function OurServices() {
  return (
    <div className="flex flex-col items-center xl:block  xl:pl-[70px] xl:pr-16  mt-14 ">
      {/* heading */}
      <div className="flex gap-5 relative">
        <div className=" bg-primary-500 h-1 w-9 xl:h-2   xl:w-24  relative top-[1rem] xl:top-[3rem]"></div>
        <div className="flex flex-grow flex-col xl:flex-row items-start justify-between">
          <div>
            <div className="our_services-title  text-5xl xl:text-9xl text-font--hind_madurai">
              Our
            </div>
            <div className="our_services-title  text-5xl xl:text-9xl text-font--hind_madurai">
              Servies
            </div>
          </div>
          <div>
            <h6 className="hidden xl:block text-3xl xl:text-[33px] leading-[1.2] font-semibold">
              How we will help you
              <br className="hidden xl:block" />
              {" grow"}
            </h6>
            <h6 className=" xl:hidden text-3xl xl:text-[33px]  leading-[1.2] font-semibold">
              How we will help
              <br className="xl:hiddden" />
              {" you grow"}
            </h6>
          </div>
        </div>
      </div>

      {/* content */}
      <div className="flex flex-col items-center xl:flex-row mt-8  xl:gap-52 relative">
        <img
          src="/assets/ourServies/bg-logo.png"
          width={368}
          className="hidden xl:block absolute top-1/2 -translate-y-1/2   left-1/2 -translate-x-1/2"
          style={{ width: "368px", aspectRatio: 1.4 }}
          alt=""
        />
        {/* small screen */}
        <img
          src="/assets/ourServies/bg-logo.png"
          width={368}
          className=" xl:hidden absolute top-1/2 -translate-y-1/2   left-1/2 -translate-x-1/2"
          style={{ width: "190px", aspectRatio: 1.4 }}
          alt=""
        />
        <div className="mx-auto xl:mx-0 w-[80%] xl:w-1/2">
          <Service></Service>
          <Service></Service>
          <Service></Service>
          <Service></Service>
        </div>
        <div className="hidden xl:flex w-1/2  justify-center items-center h-auto">
          <div
            className=" m-auto w-[408px] h-[400px]"
            style={{
              background: `url('/assets/ourServies/s1.png')`,
              objectFit: "cover",
              backgroundRepeat: "no-repeat",
            }}
          ></div>
          {/* <img
            src="/assets/header/v3.png"
            style={{ width: "408px", aspectRatio:1, maxWidth: "100%" }}
            alt=""
          /> */}
        </div>
      </div>
    </div>
  );
}
