export * from "./OurServices";

export const Service = () => {
  return (
    <div className="flex items-center pt-6 pb-[11px] border-b border-b-black gap-5 xl:gap-6 my-3">
      <div className="flex gap-5 flex-col">
        <div className="flex gap-2 items-center relative">
          <div className=" contents">
            <img src="/assets/ourServies/instagram.svg" 
          style={{ aspectRatio: 1, width: "18px", height: "18px" }}
            
            />
          </div>
          <div className=" mr-1 sm:mr-6 xl:mr-0 font-bold  text-lg sm:text-2xl leading-[1.2]">
            Social Media and Content Creation
          </div>
          <div className="xl:hidden p-2 sm:p-9"></div>
          <div className="absolute  top-0 right-0 xl:hidden">
            <img
              src="/assets/ourServies/arrow-right.svg"
              style={{ aspectRatio: 1, width: "36px", height: "36px" }}
            />
          </div>
        </div>
        <p className=" sm:text-xl">
          Our reality has gone virtual, with new platforms, creators, and trends
          emerging on a regular basis.
        </p>
      </div>
      <div className="hidden xl:contents">
        <img
          src="/assets/ourServies/arrow-right.svg"
          style={{ aspectRatio: 1, width: "36px", height: "36px" }}
        />
      </div>
    </div>
  );
};
