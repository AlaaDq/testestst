import React from 'react';

import {OurServices} from '../OurServices';

describe('<OurServices />', () => {});
