import React, { useEffect } from "react";

import "./AboutUs.css";
import { Player } from "../../../libraries";

export function AboutUs() {
  const lottieBg = "/assets/aboutUs/lottie-bg.json";
  const mobileImg = "/assets/header/v3.png";
  return (
    <div className="AboutUs min-h-[496px] flex flex-col lg:flex-row ">
      <div className="pt-[30px] xl:pt-[66px] pl-4 pr-4 xl:pl-[70px]  flex-1 flex-grow-[2]">
        <h1 className=" font-bold text-4xl xl:text-[40px] leading-[1.2] ">
          Thinking outside the box
        </h1>
        <p className=" text-3xl xl:text-[32px] mt-8   leading-[38.4px]   mb-12">
          Our reality has gone virtual, with new platforms, creators, and trends
          emerging on a regular basis. Few people can keep up with you, so how
          will you? We'll demonstrate how. Brave Bison is a media, marketing,
          and technology firm designed for the modern era.
        </p>
        <div className=" inline-block cursor-pointer text-2xl leading-6 font-semibold   border-b-[1px] border-b-black  py-3">
          <label htmlFor="">About Us</label>
        </div>
      </div>
      <div className="flex-1">
        <div>
          <div className="relative flex my-7 justify-center w-full">
            <div className=" absolute right-[25vw] lg:left-0 sm:right-0">
              <Player
                autoplay
                speed={1}
                loop
                src={lottieBg}
                className="w-44 sm:w-50 xl:w-64"
              ></Player>
            </div>
            <img
              src={mobileImg}
              className="about_us-thumble--shadow
                about_us-thumble--mobile 
                xl:hidden
                w-48
                sm:w-80
                
                mb-10
                "
              alt=""
            />
          </div>
        </div>
      </div>
    </div>
  );
}
