import React from "react";

import { AboutUs } from "../AboutUs";

describe("<AboutUs />", () => {});
