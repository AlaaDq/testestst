import React from 'react';

import {Navbar} from '../Navbar';

describe('<Navbar />', () => {});
