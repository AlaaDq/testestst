import React, { useMemo } from "react";

import "./NavbarContainer.css";

import { MobileNavbar, WebNavbar } from ".";
import { useBreakpoint } from "../../../hooks/useBreakpoint";
export function NavbarContainer(props) {
  const breakpoint = useBreakpoint();
  const mobileBreakpoint = 1280;
  const isMobile = useMemo(
    () => breakpoint < mobileBreakpoint,
    [breakpoint < mobileBreakpoint]
  );

  return (
    <>
      {/* mobile screen */}
      <MobileNavbar mobileBreakpoint={mobileBreakpoint} isMobile={isMobile} />

      {/* large screen */}
      <WebNavbar mobileBreakpoint={mobileBreakpoint} />
    </>
  );
}
