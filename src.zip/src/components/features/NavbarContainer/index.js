import { useCallback, useEffect, useState } from "react";
import { Button } from "../../ui";
export * from "./NavbarContainer";

export const links = [
  { path: "#", label: "Home" },
  { path: "#", label: "About Us" },
  { path: "#", label: "Services" },
  { path: "#", label: "Our Work" },
  { path: "#", label: "Our Products" },
  { path: "#", label: "Careers" },
  { path: "#", label: "Insights" },
  { path: "#", label: "Contact Us" },
];

export const Logo = (props) => {
  return (
    <div>
      <img src="/assets/header/logo_en.svg" {...props} />
    </div>
  );
};

export const LangBtn = (props) => {
  return <div {...props}>{props.label}</div>;
};

export const BookBtn = (props) => {
  return <Button {...props}>{props.label}</Button>;
};

export const MobileNavbarMenu = (props) => {
  return (
    <div
      className={`${
        props.isOpen ? "h-screen" : " h-0  overflow-hidden"
      }  transition-all duration-1000 fixed bg-white top-[91px] left-0 right-0 w-full  z-50 `}
    >
      <div className="flex flex-col gap-[54px] pt-2 pr-4 pb-9 pl-[18px] p-[8px,15px,38px,18px]">
        <div className="flex flex-col list-none  gap-6 2xl:gap-6  ">
          {links.map((link, index) => (
            <li
              className={`text-lg text-gray-900 uppercase transition-opacity delay-100 duration-1000 ${
                props.isOpen ? " opacity-100" : "opacity-0 "
              } leading-[1.2] font-semibold flex  py-3 `}
              key={index}
            >
              <a href={link.path}>{link.label}</a>
            </li>
          ))}
        </div>
        <BookBtn
          label="Book A Meeting"
          className="flex w-[169px] leading-[1.5]  shadow-[0_10px_30px_rgba(0,0,0,0.14)] text-white bg-primary-500 rounded-md content-center  items-center py-[9px] px-5 gap-2 text-font--montserrat "
        />
      </div>
    </div>
  );
};

export const MobileNavbar = (props) => {
  const [isOpen, setIsOpen] = useState(false);
  useEffect(() => setIsOpen(false), [props.isMobile]);
  return (
    <>
      <MobileNavbarMenu isOpen={isOpen} />
      <div className="xl:hidden h-[91px]  flex w-100 items-center justify-between py-3 px-4        shadow-[0_20px_60px_rgba(0,0,0,0.08)]">
        <Logo width={105.16} />
        <div className="flex items-center gap-3 min-[375px]:gap-12">
          <LangBtn
            label="EN"
            className="text-primary-500 font-bold flex justify-center  items-center  w-[42px] h-[42px]  text-lg "
          />
          <div
            onClick={() => setIsOpen((isOpen) => !isOpen)}
            className={`border humbrger ${
              isOpen ? "open" : ""
            } flex flex-col  cursor-pointer gap-2 p-2 justify-center items-center border-grey-900  rounded-[50%] w-[42px] h-[42px] `}
          >
            <div className=" w-full h-[1px] bg-gray-900"></div>
            <div className=" w-full h-[1px] bg-gray-900"></div>
          </div>
        </div>
      </div>
    </>
  );
};

export const WebNavbar = (props) => {
  return (
    <div
      className="max-[1279px]:hidden 
        flex 
        items-center 
        w-full  bg-white
        shadow-[0_20px_60px_rgba(0,0,0,0.08)]
        px-10  2xl:px-[70px] 2xl:gap-[80px] py-6
        h-[91px]
         "
    >
      <div className=" min-w-[105px]">
        <Logo width={105.16} />
      </div>

      <div className=" flex justify-center max-[1367px]:w-full  2xl:block">
        <div className="flex  whitespace-nowrap list-none gap-5 uppercase text-grey-900 2xl:gap-6 leading-[1.2]  font-semibold">
          {links.map((link, index) => (
            <li key={index}>
              <a href={link.path}>{link.label}</a>
            </li>
          ))}
        </div>
      </div>
      <div className=" flex gap-[1rem] 2xl:gap-[42px] p-2 items-center  flex-1 justify-end">
        <LangBtn label="EN" className="text-primary-500 font-bold   text-lg " />

        <BookBtn
          label="Book A Meeting"
          className="flex w-[169px] leading-[1.5]  shadow-[0_10px_30px_rgba(0,0,0,0.14)] text-white bg-primary-500 rounded-md content-center  items-center py-2 px-5 gap-2 text-font--montserrat "
        />
      </div>
    </div>
  );
};
