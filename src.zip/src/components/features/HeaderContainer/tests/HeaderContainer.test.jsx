import React from 'react';

import {HeaderContainer} from '../HeaderContainer';

describe('<HeaderContainer />', () => {});
