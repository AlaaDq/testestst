import React, { useEffect } from "react";
import { Header } from "../Header/Header";
import { NavbarContainer } from "../NavbarContainer";
import "./HeaderContainer.css";

export function HeaderContainer() {
  // useEffect(() => {
  //  console.log(document.querySelector('#test'))
  // }, []);
  return (
    <>
      <NavbarContainer />
      <Header />
    </>
  );
}
