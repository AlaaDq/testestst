import React, { useEffect, useRef } from "react";

import "./VideoContainer.css";

export function VideoContainer({ isVideo, playVideo }) {
  const video = useRef(null);

  return (
    <div className="VideoContainer h-[800px] overflow-hidden relative">
      {!isVideo && (
        <div
          onClick={() => playVideo(video)}
          className="  absolute flex justify-center z-10 items-center left-[20%] cursor-pointer top-[50%] translate-y-[-50%] bg-black rounded-[50%] h-[88px] w-[88px] xl:h-[188px] xl:w-[188px] "
        >
          <div className="text-white text-lg xl:text-5xl leading-[1.2]">
            Play
          </div>
        </div>
      )}
      <img
        alt=""
        src="/assets/video/video-thumbnail.png"
        className={`${
          isVideo ? "hidden " : ""
        } absolute top-0 left-0 w-screen h-[800px]`}
      ></img>
      <video
        ref={video}
        playsInline={true}
        muted="muted"
        style={{ width: "100vw", height: "800px", objectFit: "cover" }}
        className={`${isVideo ? " " : "hidden"} absolute top-0 left-0`}
      >
        <source src="/assets/video/v.mp4" type="video/mp4" />
      </video>
    </div>
  );
}
