import React from "react";

import { VideoContainer } from "../VideoContainer";

describe("<VideoContainer />", () => {});
