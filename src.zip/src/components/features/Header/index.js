import { Button } from "../../ui";
import gsap from "gsap";
import { useEffect } from "react";

export * from "./Header";

export const Cd = () => {
  useEffect(() => {
    const cdTimeline = gsap.timeline({ repeat: -1 });
    const slides = document.querySelectorAll(".header-subtitle");
    slides.forEach((slide, index) => {
      cdTimeline.from(slide, {
        duration: 1,
        opacity:0,
        y: "-100%",
        ease: "power3.easeOut",
      });
      cdTimeline.to(slide, { duration: 2, y: "0", ease: "power3.easeOut" });
      cdTimeline.to(slide, { duration: 1, y: "100%", ease: "power3.easeOut" });
      cdTimeline.set(slide,{opacity:0});
    });
  }, []);
  return (
    <div
      className={`header-subtitle_container relative overflow-hidden header-subtitle--size  mt-[11px] mb-[28px]`}
    >
      <div className={` absolute text-font--montserrat  header-subtitle`}>
        Reach target users
      </div>
      <div className={` absolute text-font--montserrat  header-subtitle`}>
        Get insights on them
      </div>
      <div className={` absolute text-font--montserrat  header-subtitle`}>
        Know your customers
      </div>
    </div>
  );

  return (
    <div
      className={`header-subtitle_container header-subtitle--size  mt-[11px] mb-[32px]`}
    >
      <div className={` text-font--montserrat  header-subtitle`}>
        Reach target users
      </div>
      <div className={` text-font--montserrat  header-subtitle`}>
        Get insights on them
      </div>
      <div className={` text-font--montserrat  header-subtitle`}>
        Know your customers
      </div>
      <div className={` text-font--montserrat  header-subtitle2`}>
        Reach target users
      </div>
      <div className={` text-font--montserrat  header-subtitle2`}>
        Get insights on them
      </div>
      <div className={` text-font--montserrat  header-subtitle2`}>
        Know your customers
      </div>
    </div>
  );
};

export const CallToActionBtn = () => {
  return (
    <Button
      variant="secondary"
      className="  shadow-[0_20px_40px_rgba(0,0,0,0.13)] max-w-[150px] sm:max-w-[230px] uppercase whitespace-nowrap mt-14 bg-black rounded-[10px]  px-3   py-4 sm:px-[38px] xl:py-[22px]  text-white"
    >
      <span className="  font-medium xl:text-2xl  text-font--hind_madurai  leading-6">
        Get In Touch
      </span>
    </Button>
  );
};
