import React, { useEffect, useState } from "react";
import { Player } from "../../../libraries";

import "./Header.css";
import { Cd, CallToActionBtn } from ".";

const lotties = [
  "/assets/header/lottie-1.json",
  "/assets/header/lottie-2.json",
  "/assets/header/lottie-3.json",
];

const images = [
  "/assets/header/v1.png",
  "/assets/header/v2.png",
  "/assets/header/v3.png",
  "/assets/header/v3.png",
];

export function Header() {
  // const [paused, setPaused] = useState(false);
  // useEffect(() => {
  //   const i = setInterval(() => {
  //     setPaused((paused) => !paused);
  //   }, 1000);
  //   return () => clearInterval(i);
  // }, []);

  return (
    <div className=" Header  h-auto xl:h-[calc(100vh-91px)]  grid grid-row-2 xl:grid-cols-2 ">
      <div className="">
        
        <div className="xl:ml-[72px] xl:mr-12  mx-auto max-w-[80%] xl:flex h-full xl:flex-col justify-center ">
          {/*  */}
          {/* text-font--montserrat  */}
          <div className="hidden xl:block header-title header-title--size  text-font--hind_madurai ">
            We help businesses
          </div>
          <div className="xl:hidden header-title text-3xl mt-10 xl:mt-0 text-font--hind_madurai ">
            We help businesses
          </div>
          {/*  */}
          <Cd />

          {/*  */}
          <div className="header-desc  text-grey-900">
            It’s either you be part of the change or be at the front making it
            all happen. Few people can keep up with you, so how will you? We'll
            demonstrate how. Brave Bison is a media, marketing, and technology
            firm designed for the modern era.
          </div>

          <CallToActionBtn />
        </div>
      </div>
      <div className="hidden xl:block">
        <div className="relative xl:ml-[72px] xl:mr-12  mx-auto max-w-[80%] xl:flex h-full xl:flex-col justify-center ">
          <div className=" absolute top-[21vh] left-[2vh]  z-10 ">
            <img
              style={{ width: "217px", " aspectRatio": 1.8 }}
              src={images[0]}
              className="header-thumble--shadow{"
              width={100}
              alt=""
            />
          </div>
          <div className=" absolute top-[5vh] ">
            <Player
              autoplay
              speed={1}
              loop
              src={lotties[0]}
              style={{ height: "300px", width: "300px" }}
            ></Player>
          </div>
          <div className=" absolute z-10   top-[31vh] right-[2vh]">
            <img
              style={{ width: "217px", " aspectRatio": 1.8 }}
              src={images[1]}
              className="header-thumble--shadow {"
              width={100}
              alt=""
            />
          </div>
          <div className=" absolute top-[21vh] right-0">
            <Player
              autoplay
              speed={1}
              loop
              src={lotties[1]}
              style={{ height: "300px", width: "300px" }}
            ></Player>
          </div>
          <div className=" absolute z-10  top-[47vh] ">
            <img
              style={{ width: "217px", " aspectRatio": 1.8 }}
              src={images[2]}
              className="header-thumble--shadow {"
              width={100}
              alt=""
            />
          </div>
          <div className=" absolute top-[50vh] ">
            <Player
              autoplay
              speed={1}
              loop
              src={lotties[2]}
              style={{ height: "300px", width: "300px" }}
            ></Player>
          </div>
          <div className=" absolute z-10 top-[60vh] right-[4vh]">
            <img
              style={{ width: "217px", aspectRatio: 1.8 }}
              src={images[2]}
              className="header-thumble--shadow {"
              width={100}
              alt=""
              id="test"
            />
          </div>
        </div>
      </div>
      <div className="flex   my-16 gap-24 items-center flex-col xl:hidden">
        {images.map((img, index) => (
          <div className=" relative" key={index}>
            {index < lotties.length && (
              <div className=" absolute top-[1vh] ">
                <Player
                  autoplay
                  speed={1}
                  loop
                  src={lotties[index]}
                  style={{ height: "200px", width: "200px" }}
                ></Player>
              </div>
            )}

            <img
              src={img}
              className="header-thumble--shadow header-thumble--mobile 
              
                w-48
                sm:w-72
                lg:w-75
              "
              alt=""
            />
          </div>
        ))}
      </div>
    </div>
  );
}
