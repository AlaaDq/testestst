import React from "react";
import { Button } from "../../ui";

import styles from "./Footer.css";

export function Footer() {
  return (
    <div className="  py-12 bg-black min-h-[50vh]">
      <div className=" px-4  xl:pl-[70px] xl:flex xl:justify-between">
        {/* title */}
        <div className="flex  flex-col gap-8">
          <h4 className=" text-white  font-semibold text-2xl">
            Get action from our universe
            <br className="hidden xl:block" />
            delivered straight to your inbox.
          </h4>
          <div class="relative border-b border-b-gray-600">
            <input
              class="bg-black text-white rounded-md p-2 w-full"
              type="text"
            />
            <label
              class="absolute top-0 left-0 p-2 text-xs  text-font--montserrat text-white pointer-events-none transition duration-150 ease-in-out"
              id="label"
            >
              Email Address <span className=" text-primary-500"> *</span>
            </label>
          </div>
          <Button className="text-font--montserrat w-[167px] py-3 px-11 rounded-md">
            Subscribe
          </Button>
        </div>

        {/*  links */}
        <div className="flex mt-12 xl:gap-16 xl:mt-0 justify-between">
          {/* quick */}
          <div className="flex-1">
            <h4 className=" text-white  mb-5    font-semibold text-2xl">
              Quick Links
            </h4>
            <div className="flex gap-4 flex-col">
              <div className="text-white uppercase">About</div>
              <div className="text-white uppercase">Services</div>
              <div className="text-white uppercase">Our Work</div>
              <div className="text-white uppercase">Careers</div>
              <div className="text-white uppercase">Insights</div>
              <div className="text-white uppercase">Contact Us</div>
            </div>
          </div>
          {/* social */}
          <div className="flex-1 items-end">
            <h4 className=" text-white mb-5  font-semibold text-2xl">
              Social Media
            </h4>
            <div className="flex gap-4 flex-col">
              <div className="flex gap-2 items-center">
                <img
                  src="/assets/footer/s4.svg"
                  style={{ height: "16px", width: "16px" }}
                  alt=""
                />
                <div className="text-white uppercase">Facebook</div>
              </div>
              <div className="flex gap-2 items-center">
                <img
                  src="/assets/footer/s1.svg"
                  style={{ height: "16px", width: "16px" }}
                  alt=""
                />
                <div className="text-white uppercase">Instagram</div>
              </div>
              <div className="flex gap-2 items-center">
                <img
                  src="/assets/footer/s2.svg"
                  style={{ height: "16px", width: "16px" }}
                  alt=""
                />
                <div className="text-white uppercase">Twitter</div>
              </div>
              <div className="flex gap-2 items-center">
                <img
                  src="/assets/footer/s3.svg"
                  style={{ height: "16px", width: "16px" }}
                  alt=""
                />
                <div className="text-white uppercase">LinkedIn</div>
              </div>
            </div>
          </div>
        </div>

        {/* location */}
        <div className="flex 2xl:gap-12 xl:gap-9 flex-col">
          {/* visit us */}
          <div className=" mt-9 xl:mt-0 ">
            <h4 className=" text-white mb-7  font-semibold text-2xl">
              Visit Us At
            </h4>
            <div className="flex gap-3">
              <div>
                <img
                  src="/assets/footer/location.svg"
                  style={{ height: "16px", width: "13px" }}
                  alt=""
                />
              </div>
              <div className="flex flex-col gap-3">
                <div className=" uppercase text-white leading-[19.2px]">
                  Office 901, Clover Bay Tower
                </div>
                <div className="uppercase text-white leading-[19.2px]">
                  Dubai, bUSINESS bAY Area
                </div>
              </div>
            </div>
          </div>

          {/* contact */}
          <div className=" mt-9 xl:mt-0 xl:mr-32 ">
            <h4 className=" text-white mb-5  font-semibold text-2xl">
              Contact Details
            </h4>
            <div>
              <div className="flex gap-[10px] flex-col">
                <div className="flex  gap-4 items-center">
                  <img
                    src="/assets/footer/email.svg"
                    style={{ height: "16px", width: "16px" }}
                    alt=""
                  />
                  <div className="text-white ">info@no9ine.ae</div>
                </div>
                <div className="flex gap-4 items-center">
                  <img
                    src="/assets/footer/phone.svg"
                    style={{ height: "16px", width: "16px" }}
                    alt=""
                  />
                  <div className="text-white ">+971 54 339 9359</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* logo */}
      <div className="px-4   xl:pl-[41px]">
        <div className="inline-block xl:flex justify-between mt-9 mb-6">
          <div>
            <img
              src="/assets/footer/logo.svg"
              style={{ height: "102px" }}
              alt=""
            />
          </div>
          <div className=" mt-6 xl:mr-28 ">
            <div className="text-white font-bold  text-xl">
              <span className=" text-primary-500">We are NO9INE </span>always a
              <span className=" relative">
                Ten
                <div className="absolute right-0">
                  <img
                    src="/assets/footer/slash.svg"
                    alt=""
                    style={{ height: "17px" }}
                  />
                </div>
              </span>
            </div>
          </div>
        </div>
      </div>
      {/* policy */}
      <div className="px-4 xl:pl-[41px] ">
        <div className="mt-8 xl:flex xl:w-1/2 xl:gap-2">
          <div className=" text-grey-300 font-semibold mb-3 ">
            © 2022 No9ine Marketing — Digital Marketing Agency | All Rights
            Reserved
          </div>
          <div className=" font-bold text-white uppercase">Privacy Policy</div>
        </div>
      </div>
    </div>
  );
}
