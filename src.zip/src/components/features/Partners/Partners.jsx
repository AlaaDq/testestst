import React from "react";

import "./Partners.css";
const logos1 = [
  "/assets/partners/logo-1.svg",
  "/assets/partners/logo-2.svg",
  "/assets/partners/logo-3.svg",
  "/assets/partners/logo-4.svg",
  "/assets/partners/logo-2.svg",
  "/assets/partners/logo-3.svg",
  "/assets/partners/logo-4.svg",
];
const logos2 = [
  "/assets/partners/logo-1.svg",
  "/assets/partners/logo-2.svg",
  "/assets/partners/logo-3.svg",
  "/assets/partners/logo-4.svg",
  "/assets/partners/logo-2.svg",
  "/assets/partners/logo-3.svg",
  "/assets/partners/logo-4.svg",
];
const logos3 = [
  "/assets/partners/logo-1.svg",
  "/assets/partners/logo-2.svg",
  "/assets/partners/logo-3.svg",
  "/assets/partners/logo-4.svg",
  "/assets/partners/logo-2.svg",
  "/assets/partners/logo-3.svg",
  "/assets/partners/logo-4.svg",
];
export function Partners() {
  return (
    <div>
      <h1 className="font-bold text-3xl leading-[1.2] text-center mb-28">
        Our partners who trust us
      </h1>
      {/*  */}

      <div className="relative min-h-[1.75rem] mb-6 xl:mb-16 xl:min-h-[3rem] flex items-center  overflow-hidden w-full">
        <div className=" absolute flex animate  w-[200%] left-0">
          <div className="flex flex-1 w-50 gap-6 xl:gap-0 justify-around">
            {logos1.map((logo, index) => (
              <div className="" key={`${index}-${logo}`}>
                <img src={logo} className="h-7 xl:h-12" alt="" />
              </div>
            ))}
          </div>
          <div className="flex flex-1  w-50 gap-6 xl:gap-0 justify-around">
            {logos1.map((logo) => (
              <div className="">
                <img src={logo} className="h-7 xl:h-12" alt="" />
              </div>
            ))}
          </div>
        </div>
      </div>
      {/*  */}
      <div className="relative  min-h-[1.75rem] mb-6 xl:mb-16  xl:min-h-[3rem] flex items-center  overflow-hidden w-full">
        <div className=" absolute flex animate  reverse w-[200%] left-0">
          <div className="flex flex-1 w-50 gap-6 xl:gap-0 justify-around">
            {logos2.map((logo, index) => (
              <div className="" key={`${index}-${logo}`}>
                <img src={logo} className="h-7 xl:h-12" alt="" />
              </div>
            ))}
          </div>
          <div className="flex flex-1  w-50 gap-6 xl:gap-0 justify-around">
            {logos2.map((logo) => (
              <div className="">
                <img src={logo} className="h-7 xl:h-12" alt="" />
              </div>
            ))}
          </div>
        </div>
      </div>
      {/*  */}

      <div className="relative min-h-[1.75rem] xl:min-h-[3rem]   flex items-center  overflow-hidden w-full">
        <div className=" absolute flex animate  w-[200%] left-0">
          <div className="flex flex-1 w-50 gap-6 xl:gap-0 justify-around">
            {logos2.map((logo, index) => (
              <div className="" key={`${index}-${logo}`}>
                <img src={logo} className="h-7 xl:h-12" alt="" />
              </div>
            ))}
          </div>
          <div className="flex flex-1  w-50 gap-6 xl:gap-0 justify-around">
            {logos1.map((logo) => (
              <div className="">
                <img src={logo} className="h-7 xl:h-12" alt="" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
