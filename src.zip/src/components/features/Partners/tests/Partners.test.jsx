import React from 'react';

import {Partners} from '../Partners';

describe('<Partners />', () => {});
