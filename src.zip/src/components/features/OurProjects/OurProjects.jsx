import React from "react";

import "./OurProjects.css";
import { Project } from ".";
export function OurProjects() {
  return (
    <>
      {/* heading */}
      <div className="flex flex-col  w-full px-4 xl:block  xl:pl-[70px] xl:pr-16  mt-14">
        <div className="flex px-1 gap-5 relative">
          <div className=" bg-primary-500 h-1 w-9 xl:h-2   xl:w-24  relative top-[1rem] xl:top-[3rem]"></div>
          <div className="flex flex-grow flex-col xl:flex-row items-start justify-between">
            <div className=" mb-10 xl:mb-0">
              <div className="our_services-title    text-5xl sm:text-7xl xl:text-9xl text-font--hind_madurai">
                Our
              </div>
              <div className="our_services-title  text-5xl sm:text-7xl  xl:text-9xl text-font--hind_madurai">
                Projects
              </div>
            </div>
            <div>
              <h6 className="hidden xl:block text-3xl xl:text-[33px] leading-[1.2] font-semibold">
                View what we have been
                <br className="hidden xl:block" />
                {" upto"}
              </h6>
              <h6 className=" xl:hidden text-4xl sm:text-5xl  xl:text-[33px]  leading-[1.2] font-semibold">
                View what we have
                <br className="xl:hiddden" />
                {" been upto"}
              </h6>
            </div>
          </div>
        </div>
      </div>

      {/* content */}
      <div className="flex   mt-8 flex-col">
        <div className="relative mb-28  overflow-hidden">
          <Project />
          <h2 className=" whitespace-nowrap bottom-0 right-0 font-bold  text-gray-50 text-[3.8rem] xl:text-8xl absolute">
            Branding and Content Creation
          </h2>
        </div>
        <div className="relative mb-28  overflow-hidden">
          <Project reverse />
          <h2 className=" whitespace-nowrap bottom-0 right-0 font-bold  text-gray-50 text-8xl absolute">
            Branding and Content Creation
          </h2>
        </div>
        <div className="relative mb-28 overflow-hidden">
          <Project />
          <h2 className=" whitespace-nowrap bottom-0 right-0 font-bold  text-gray-50 text-8xl absolute">
            Branding and Content Creation
          </h2>
        </div>
      </div>
    </>
  );
}
