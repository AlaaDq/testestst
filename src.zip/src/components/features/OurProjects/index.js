import { PopupLink } from "../../ui";

export * from "./OurProjects";

export const Project = ({ reverse = false }) => {
  return (
    <div
      className={`flex xl:px-[70px] ${[
        reverse ? " xl:flex-row-reverse" : "xl:flex-row",
      ]} 
       flex-col   items-center
      `}
    >
      <div
        className={`xl:w-2/3 flex flex-col  justify-center ${[
          reverse ? " xl:items-end" : " xl:items-start",
        ]}
        w-full px-4 xl:px-0
        `}
      >
        <div className="w-full px-4 sm:px-0 sm:w-3/4 xl:w-1/3 flex flex-col gap-[18px]">
          <div className=" font-bold text-xl text-primary-500 leading-[1.2] xl:text-[1.4rem]">
            Nike
          </div>
          <div className=" font-bold leading-[1.2] text-3xl xl:text-[2rem]">
            Helping Nike increase it reach by 20% in Eastern Africa
          </div>
          <div className=" text-xl leading-[1.2]">
            Making Nike reach 200,000 customers by ccreating a social media
            campagin by showing how much they care about the community.
          </div>
          <div className=" mt-4  mb-14 xl:mb-0">
            <PopupLink className=" inline-block cursor-pointer text-2xl leading-6 font-semibold   border-b-[1px] border-b-black  py-3">
              View Case Study
            </PopupLink>
          </div>
        </div>
      </div>
      <div
        className="xl:w-1/3 -translate-y-10  w-full px-4 xl:px-none xl:translate-y-0
            z-[1]
      "
      >
        <div
          className="h-[75vh] bg-gray-200  w-full  z-[10] relative"
          style={{
            background: "url(/assets/ourProjects/p.png)",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
          }}
        ></div>
      </div>
    </div>
  );
};
