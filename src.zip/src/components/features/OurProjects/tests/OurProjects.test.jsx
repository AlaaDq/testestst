import React from 'react';

import {OurProjects} from '../OurProjects';

describe('<OurProjects />', () => {});
