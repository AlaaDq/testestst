import React from "react";

import "./Typography.css";

export function Typography({
  element = "div",
  size = "medium",
  classes = "",
  children,
  ...props
}) {
  return (
    <element className={` typography-${size} ${classes}`} {...props}>
      {children}
    </element>
  );
}
