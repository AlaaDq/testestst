import React from "react";

import "./Button.css";

export function Button({ children, variant = "primary", outline, ...props }) {
  let className = `button button-${variant}`;
  if (outline) {
    className += ` button-outline-${variant}`;
  }
  className += ` ${props.className || ""}`;
  if (variant == "secondary")
    return (
      <button {...props} className={`${className} button-secondary`}>
        {children}
      </button>
    );
  else if (variant == "outline")
    return (
      <button {...props} className={`${className} button-outline`}>
        {children}
      </button>
    );
  else
    return (
      <button {...props} className={`${className} button-primary`}>
        {children}
      </button>
    );
}
