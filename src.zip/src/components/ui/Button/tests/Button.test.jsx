import React from 'react';

import {Button} from '../Button';

describe('<Button />', () => {});
