import React from 'react';

import {PopupLink} from '../PopupLink';

describe('<PopupLink />', () => {});
