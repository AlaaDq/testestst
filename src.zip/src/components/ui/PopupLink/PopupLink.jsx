import React from "react";

import "./PopupLink.css";

export function PopupLink(props) {
  return <div {...props}>{props.children || ""}</div>;
}
