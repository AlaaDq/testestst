import React, { useEffect, useState, useMemo } from "react";
import {
  AboutUs,
  HeaderContainer,
  VideoContainer,
  OurServices,
  Partners,
  Footer,
} from "../../components";

import "./Home.css";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useBreakpoint } from "../../hooks/useBreakpoint";
import { OurProjects } from "../../components/features/OurProjects/OurProjects";
gsap.registerPlugin(ScrollTrigger);

export function Home() {
  const breakpoint = useBreakpoint();
  const mobileBreakpoint = 1280;
  const isMobile = useMemo(
    () => breakpoint < mobileBreakpoint,
    [breakpoint < mobileBreakpoint]
  );

  //use video hook resucer will control isvideo and play pause resetart helpers
  const [isVideo, setIsVideo] = useState(false);

  const playVideo = (video) => {
    setIsVideo(true);
    video.currentTime = 0;
    video?.play?.();
  };

  function animate() {
    const el = document.querySelector("#test");
    const video = document.querySelector("video");
    let ctx = gsap.context(() => {
      const imageToVideoTimeLine1 = gsap
        .timeline({
          scrollTrigger: {
            // markers: true,
            trigger: ".AboutUs",
            // el , vp
            start: "top bottom-=200",
            end: "bottom bottom-=200",
            scrub: 0.5, // block animation with scroll (true , 1,2)
            pin: el, // pin image while scroll
            pinSpacing: true,
          },
          opacity: 1,
        })
        .to(el, {
          scrollTrigger: {
            // markers: true,
            trigger: ".AboutUs",
            // el , vp
            start: "top top",
            end: "center+=75 top",
            scrub: 0.5, // block animation with scroll (true , 1,2)
            pin: el, // pin img while scroll
            pinSpacing: true,
            onEnterBack: () => {
              console.log("first onEnterBack");
            },
            onLeaveBack: () => {
              setIsVideo(false);
              video.pause();
              console.log("first onLeaveBack");
            },
            onLeave: ({ progress, direction, isActive }) => {
              video.currentTime = 0;
              setIsVideo(true);
              video.play();
              console.log("first onLeave");
            },
            onEnter: () => {
              setIsVideo(false);
              console.log("first onEnter");
              video.pause();
            },
          },
          opacity: 0,
        })
        .to(video, {
          scrollTrigger: {
            // markers: true,
            trigger: ".VideoContainer",
            // el , vp
            start: "top top",
            end: "bottom top",
            scrub: true, // block animation with scroll (true , 1,2)
            // pin: el,
            // pinSpacing: true,
            onEnterBack: () => {
              console.log("onEnterBack");
            },
            onLeaveBack: () => {
              video.currentTime = 0;
              setIsVideo(true);
              video.play();
              // show video
              console.log("onLeaveBack");
            },
            onLeave: ({ progress, direction, isActive }) => {
              // video.currentTime = 0;
              // video.play();
              setIsVideo(false);
              // show image
              console.log("onLeave");
            },
            onEnter: () => {
              // console.log("onEnter");
              // video.pause();
            },
          },
        });
    });
    return ctx;
  }

  useEffect(() => {
    let cleanup;
    if (!isMobile) cleanup = animate();
    return () => {
      console.log("clean up!!!");
      // if needed
      // const video = document.querySelector("video");
      // video.pause();
      //
      setIsVideo(false); /// test if it cause infint rerendering loop
      cleanup?.revert();
    };

    /** */
  }, [isMobile]);
  return (
    <>
      <HeaderContainer />
      <AboutUs />
      <VideoContainer playVideo={playVideo} isVideo={isVideo} />
      <OurServices />
      <OurProjects />
      <Partners />
      <div className="min-h-[1024px] mt-3"></div>
      <Footer />
    </>
  );
}
